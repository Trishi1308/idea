import React from 'react';
import { Calendar, Users, Target, CheckCircle } from 'lucide-react';

export default function CaseStudy() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative bg-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              The Smart Tractor Project
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              How John transformed his agricultural engineering passion into a successful venture
            </p>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            <div className="flex gap-8">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-full">
                  <Calendar className="h-6 w-6 text-purple-600" />
                </div>
                <div className="flex-1 w-px bg-purple-200 my-4"></div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">The Beginning</h3>
                <p className="text-gray-600 mb-4">
                  John, a mechanical engineering graduate, had always dreamed of revolutionizing farming
                  through sustainable technology. With years of experience working on his family's farm,
                  he identified key inefficiencies in traditional farming equipment.
                </p>
                <img
                  src="https://images.unsplash.com/photo-1592982537447-6f2a6e0a3023?auto=format&fit=crop&q=80"
                  alt="Farm Equipment"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>

            <div className="flex gap-8">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-full">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
                <div className="flex-1 w-px bg-purple-200 my-4"></div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">Joining idea</h3>
                <p className="text-gray-600 mb-4">
                  After joining our platform, John received support for his basic living expenses,
                  allowing him to focus full-time on developing his smart tractor prototype.
                  We connected him with mentors in the agricultural technology sector.
                </p>
              </div>
            </div>

            <div className="flex gap-8">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-full">
                  <Target className="h-6 w-6 text-purple-600" />
                </div>
                <div className="flex-1 w-px bg-purple-200 my-4"></div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">Development & Testing</h3>
                <p className="text-gray-600 mb-4">
                  Over 8 months, John developed a prototype that incorporated AI-driven precision
                  farming capabilities, solar charging, and autonomous operation features.
                  Initial field tests showed a 40% reduction in fuel consumption.
                </p>
                <img
                  src="https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&q=80"
                  alt="Tractor Prototype"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>

            <div className="flex gap-8">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-full">
                  <CheckCircle className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">Success & Investment</h3>
                <p className="text-gray-600 mb-4">
                  John's project caught the attention of a major agricultural equipment manufacturer,
                  leading to a $2M investment. He contributed 20% of this investment back to idea,
                  helping fund the next generation of innovators.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="bg-purple-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Project Impact</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Environmental</h3>
              <p className="text-gray-600">40% reduction in fuel consumption and carbon emissions</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Economic</h3>
              <p className="text-gray-600">30% decrease in operational costs for farmers</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Social</h3>
              <p className="text-gray-600">Created 15 new jobs in rural communities</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}