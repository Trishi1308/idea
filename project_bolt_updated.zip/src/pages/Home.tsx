import React from 'react';
import { ArrowRight, Target, Heart, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative bg-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Turn Your Passion Into Your Career
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              We support passionate individuals by covering living expenses while they work on projects they love. Build your future doing what matters to you.
            </p>
            <Link
              to="/apply"
              className="inline-flex items-center px-6 py-3 rounded-full bg-purple-600 text-white hover:bg-purple-700 transition"
            >
              Start Your Journey <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* How It Works */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-6 flex items-center justify-center bg-purple-100 rounded-full">
                <Target className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Share Your Vision</h3>
              <p className="text-gray-600">Tell us about your passion project and how you plan to make it a reality.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-6 flex items-center justify-center bg-purple-100 rounded-full">
                <Heart className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Get Support</h3>
              <p className="text-gray-600">Receive living expense coverage while you focus on building your dream.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-6 flex items-center justify-center bg-purple-100 rounded-full">
                <DollarSign className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Give Back</h3>
              <p className="text-gray-600">Share 20% of your first success to help others achieve their dreams.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Success Story Preview */}
      <section className="bg-gray-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1532467411038-57680e3dc0f1?auto=format&fit=crop&q=80"
                alt="Success Story"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">From Dream to Reality</h2>
              <p className="text-gray-600 mb-8">
                Meet John, who turned his passion for sustainable agriculture into a revolutionary smart tractor design.
                With our support, he was able to focus full-time on his project and attract major investment.
              </p>
              <Link
                to="/case-study"
                className="inline-flex items-center text-purple-600 hover:text-purple-700"
              >
                Read His Story <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}