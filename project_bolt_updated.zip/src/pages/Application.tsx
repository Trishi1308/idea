import React from 'react';
import { FormProvider } from '../components/application/FormContext';
import ProgressBar from '../components/application/ProgressBar';
import TextAreaStep from '../components/application/TextAreaStep';
import FileUploadStep from '../components/application/FileUploadStep';
import NavigationButtons from '../components/application/NavigationButtons';
import { useForm } from '../components/application/FormContext';

function ApplicationForm() {
  const { step } = useForm();

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <ProgressBar />
      
      <div className="mb-8">
        {step === 1 && (
          <TextAreaStep
            title="Tell us about yourself"
            field="about"
            placeholder="Share your story, background, and what drives you..."
          />
        )}

        {step === 2 && (
          <TextAreaStep
            title="What are your goals in life?"
            field="goals"
            placeholder="Describe your long-term vision and what you want to achieve..."
          />
        )}

        {step === 3 && (
          <TextAreaStep
            title="How do you plan to get there?"
            field="plan"
            placeholder="Detail your strategy and the steps you'll take..."
          />
        )}

        {step === 4 && (
          <TextAreaStep
            title="What is your passion?"
            field="passion"
            placeholder="Tell us what you're truly passionate about and interested in doing..."
          />
        )}

        {step === 5 && (
          <TextAreaStep
            title="What is your current skillset?"
            field="skills"
            placeholder="List your skills, expertise, and areas of knowledge..."
          />
        )}

        {step === 6 && <FileUploadStep />}
      </div>

      <NavigationButtons />
    </div>
  );
}

export default function Application() {
  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <FormProvider>
          <ApplicationForm />
        </FormProvider>
      </div>
    </div>
  );
}