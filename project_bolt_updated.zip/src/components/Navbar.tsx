import React from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center space-x-2">
            <Lightbulb className="h-8 w-8 text-purple-600" />
            <span className="font-bold text-xl text-gray-900">idea</span>
          </Link>
          <div className="flex space-x-8">
            <Link to="/" className="text-gray-700 hover:text-purple-600 transition">Home</Link>
            <Link to="/case-study" className="text-gray-700 hover:text-purple-600 transition">Case Study</Link>
            <Link to="/apply" className="px-4 py-2 rounded-full bg-purple-600 text-white hover:bg-purple-700 transition">
              Apply Now
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}