import React from 'react';
import FormStep from './FormStep';
import { useForm } from './FormContext';

interface TextAreaStepProps {
  title: string;
  field: string;
  placeholder: string;
}

export default function TextAreaStep({ title, field, placeholder }: TextAreaStepProps) {
  const { formData, updateField } = useForm();

  return (
    <FormStep title={title}>
      <textarea
        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
        rows={6}
        placeholder={placeholder}
        value={formData[field as keyof typeof formData] as string}
        onChange={(e) => updateField(field as keyof typeof formData, e.target.value)}
      />
    </FormStep>
  );
}