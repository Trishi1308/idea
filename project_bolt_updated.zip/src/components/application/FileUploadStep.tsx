import React from 'react';
import { Upload } from 'lucide-react';
import FormStep from './FormStep';
import { useForm } from './FormContext';

export default function FileUploadStep() {
  const { updateField } = useForm();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      updateField('files', Array.from(e.target.files));
    }
  };

  return (
    <FormStep title="Upload your past experience">
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <p className="text-gray-600 mb-2">Drag and drop your files here, or click to select files</p>
        <p className="text-sm text-gray-500">PDF, DOC, DOCX up to 10MB</p>
        <input
          type="file"
          className="hidden"
          onChange={handleFileChange}
          multiple
          accept=".pdf,.doc,.docx"
        />
      </div>
    </FormStep>
  );
}