import React from 'react';

interface FormStepProps {
  title: string;
  children: React.ReactNode;
}

export default function FormStep({ title, children }: FormStepProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      {children}
    </div>
  );
}