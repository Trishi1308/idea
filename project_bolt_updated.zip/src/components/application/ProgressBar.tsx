import React from 'react';
import { useForm } from './FormContext';

export default function ProgressBar() {
  const { step } = useForm();
  const totalSteps = 6;
  const progress = (step / totalSteps) * 100;

  return (
    <div className="mb-8">
      <div className="flex justify-between mb-2">
        <span className="text-sm text-gray-600">Step {step} of {totalSteps}</span>
        <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
      </div>
      <div className="h-2 bg-gray-200 rounded-full">
        <div 
          className="h-full bg-purple-600 rounded-full transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}