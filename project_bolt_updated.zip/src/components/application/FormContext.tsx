import React, { createContext, useContext, useState } from 'react';

interface FormData {
  about: string;
  goals: string;
  plan: string;
  passion: string;
  skills: string;
  files: File[];
}

interface FormContextType {
  formData: FormData;
  updateField: (field: keyof FormData, value: any) => void;
  step: number;
  nextStep: () => void;
  prevStep: () => void;
  isValid: boolean;
}

const initialFormData: FormData = {
  about: '',
  goals: '',
  plan: '',
  passion: '',
  skills: '',
  files: []
};

const FormContext = createContext<FormContextType | undefined>(undefined);

export function FormProvider({ children }: { children: React.ReactNode }) {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [step, setStep] = useState(1);
  const totalSteps = 6;

  const updateField = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const nextStep = () => setStep(prev => Math.min(prev + 1, totalSteps));
  const prevStep = () => setStep(prev => Math.max(prev - 1, 1));

  const isValid = formData[Object.keys(formData)[step - 1] as keyof FormData] !== '';

  return (
    <FormContext.Provider value={{ formData, updateField, step, nextStep, prevStep, isValid }}>
      {children}
    </FormContext.Provider>
  );
}

export function useForm() {
  const context = useContext(FormContext);
  if (!context) {
    throw new Error('useForm must be used within a FormProvider');
  }
  return context;
}