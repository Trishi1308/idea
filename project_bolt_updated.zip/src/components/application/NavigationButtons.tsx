import React from 'react';
import { useForm } from './FormContext';

export default function NavigationButtons() {
  const { step, nextStep, prevStep, isValid } = useForm();
  const totalSteps = 6;

  const handleNext = () => {
    if (step === totalSteps) {
      // Handle form submission
      console.log('Form submitted');
      return;
    }
    nextStep();
  };

  return (
    <div className="flex justify-between">
      <button
        onClick={prevStep}
        className={`px-6 py-2 rounded-full ${
          step === 1 ? 'bg-gray-200 text-gray-400' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
        }`}
        disabled={step === 1}
      >
        Previous
      </button>
      <button
        onClick={handleNext}
        disabled={!isValid}
        className={`px-6 py-2 rounded-full ${
          isValid
            ? 'bg-purple-600 text-white hover:bg-purple-700'
            : 'bg-purple-300 text-white cursor-not-allowed'
        }`}
      >
        {step === totalSteps ? 'Submit' : 'Next'}
      </button>
    </div>
  );
}